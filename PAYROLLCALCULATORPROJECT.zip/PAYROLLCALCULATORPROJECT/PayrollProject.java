/*.
 * package PAYROLLCALCULATORPROJECT;
 * Program Name: PayrollCalculator
 * Author: [Your Name]
 * Course: [Course Name and Number]
 * Instructor: [Instructor's Name]
 * Date Submitted: April 12, 2025
 */
package PAYROLLCALCULATORPROJECT;

import java.util.Scanner;

public class PayrollProject {

    public static void main(String[] args) {
        // Constants for deduction rates
        final double FEDERAL_TAX_RATE = 0.15;
        final double STATE_TAX_RATE = 0.0307;
        final double MEDICARE_RATE = 0.0145;
        final double SOCIAL_SECURITY_RATE = 0.062;
        final double UNEMPLOYMENT_INSURANCE_RATE = 0.0007;

        Scanner input = new Scanner(System.in);

        // Get employee input
        System.out.print("Enter employee's name: ");
        String name = input.nextLine();

        System.out.print("Enter hourly rate of pay: ");
        double rateOfPay = input.nextDouble();

        System.out.print("Enter hours worked: ");
        double hoursWorked = input.nextDouble();

        double overtimeHours = 0;
        double grossPay;

        // Calculate gross pay
        if (hoursWorked <= 40) {
            grossPay = hoursWorked * rateOfPay;
        } else {
            overtimeHours = hoursWorked - 40;
            grossPay = (40 * rateOfPay) + (overtimeHours * rateOfPay * 1.5);
        }

        // Calculate deductions
        double federalTax = grossPay * FEDERAL_TAX_RATE;
        double stateTax = grossPay * STATE_TAX_RATE;
        double medicare = grossPay * MEDICARE_RATE;
        double socialSecurity = grossPay * SOCIAL_SECURITY_RATE;
        double unemploymentInsurance = grossPay * UNEMPLOYMENT_INSURANCE_RATE;

        double totalDeductions = federalTax + stateTax + medicare + socialSecurity + unemploymentInsurance;

        // Calculate net pay
        double netPay = grossPay - totalDeductions;

        // Display results
        System.out.println("\n--- Payroll Summary ---");
        System.out.println("Employee Name: " + name);
        System.out.printf("Rate of Pay: $%.2f\n", rateOfPay);
        System.out.printf("Hours Worked: %.2f\n", hoursWorked);
        System.out.printf("Overtime Hours: %.2f\n", overtimeHours);
        System.out.printf("Gross Pay: $%.2f\n", grossPay);
        System.out.printf("Total Deductions: $%.2f\n", totalDeductions);
        System.out.printf("Net Pay: $%.2f\n", netPay);
    }
}
